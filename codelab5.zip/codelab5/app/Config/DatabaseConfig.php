<?php

namespace app\config;

class DatabaseConfig {
    public $host = "localhost";
    public $user = "root";
    public $password = "";
    public $database_name = "praktikum";
    public $port = 3306;
}